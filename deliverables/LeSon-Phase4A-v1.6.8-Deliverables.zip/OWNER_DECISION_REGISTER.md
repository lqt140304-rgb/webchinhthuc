# SỔ ĐĂNG KÝ QUYẾT ĐỊNH CHỦ DỰ ÁN (OWNER DECISION REGISTER)
## Single-Facility Veterinary Hospital Management System & Generic Excel Import Center Specification (v1.6.8 - Frozen Decision Register Baseline)

- **Dự án:** Bệnh viện Thú y Lê Sơn (`lqt140304-rgb/webchinhthuc`)
- **Mã tài liệu kiến trúc:** `LESON-ARCH-PHASE4A-20261103-V1.6.8`
- **Ngày cập nhật:** 05/11/2026
- **Đơn vị điều phối:** ChatGPT (CEO Điều phối)
- **Đơn vị thẩm định độc lập:** Claude (Independent QA Reviewer)
- **Tác giả tài liệu:** Antigravity (Senior Product Designer & System Architect)
- **Trạng thái:** **`DRAFT — AWAITING INDEPENDENT QA`** *(Tài liệu đặc tả kiến trúc; KHÔNG triển khai sản xuất, KHÔNG chi tiêu ngân sách khi chưa có lệnh riêng)*

---

> [!IMPORTANT]
> ### NGUYÊN TẮC PHÂN ĐỊNH TRẠNG THÁI QUYẾT ĐỊNH
> - **`APPROVED — ARCHITECTURE / DESIGN / POLICY`**: Chủ dự án phê duyệt về mặt chủ trương thiết kế, mô hình kỹ thuật và chính sách dữ liệu. **TUYỆT ĐỐI KHÔNG COI ĐÂY LÀ PHÊ DUYỆT CHI PHÍ, MUA SẮM DỊCH VỤ TRẢ PHÍ HAY LỆNH TRIỂN KHAI PRODUCTION.**
> - **`CONFIRMED — OPERATIONS`**: Chủ dự án xác nhận đặc thù thực tế tại cơ sở; hệ thống thiết kế linh hoạt hỗ trợ nhưng không tự động công bố trên các kênh công khai khi chưa có quy trình chi tiết.
> - **`PENDING / DEFERRED`**: Các nội dung Chủ dự án chưa quyết định hoặc đang chờ rà soát pháp lý/vận hành độc lập. Hệ thống giữ nguyên trạng thái mở, cung cấp phương án so sánh và không tự ý đưa ra lựa chọn thay cho Chủ dự án.

---

> [!IMPORTANT]
> ### THÔNG BÁO ĐÓNG BĂNG VĨNH VIỄN SỔ ĐĂNG KÝ QUYẾT ĐỊNH (DECISION REGISTER FREEZE NOTICE — v1.6.8)
> Kể từ phiên bản **v1.6.8 (05/11/2026)**, toàn bộ **20 Quyết định vận hành cốt lõi (D-01 đến D-20)** cùng **4 mã mở rộng** (D-01-PRO, D-06-INVOICE, D-08-NIGHT, D-LINK) được **CHÍNH THỨC ĐÓNG BĂNG VĨNH VIỄN (OFFICIALLY FROZEN & IMMUTABLE)** ở trạng thái **100% CLOSED (APPROVED hoặc CONFIRMED)** sau khi Chủ dự án đã phê duyệt toàn diện.
> - **Nguyên tắc bất biến về mã số:** Tuyệt đối không thay đổi mã, không hoán đổi vị trí, không tách gộp hoặc đánh số lại bất kỳ quyết định nào từ D-01 đến D-20.
> - **Bảo toàn trạng thái phê duyệt:** Không hạ cấp bất kỳ quyết định nào đã phê duyệt thành PENDING hoặc OPEN.
> - **Quy định mở rộng tương lai:** Mọi quyết định vận hành / kiến trúc phát sinh mới từ các giai đoạn tiếp theo (nếu có yêu cầu từ Chủ dự án) bắt buộc phải bắt đầu đánh số từ **D-21** trở đi.

---

## I. BẢNG ÁNH XẠ QUYẾT ĐỊNH CHỦ DỰ ÁN (OWNER DECISION MAPPING MATRIX)

Bảng đối chiếu phục vụ truy vết tính nhất quán giữa bộ mã quyết định gốc (Baseline v1.6.5), các mã mở rộng chuẩn hóa v1.6.7 (Solving U-7), nội dung quyết định và trạng thái phê duyệt chính thức ngày 05/11/2026:

| Mã Gốc (v1.6.5) | Mã Mở Rộng v1.6.7 | Tên Quyết Định Vận Hành / Kỹ Thuật | Trạng Thái Cập Nhật (05/11/2026) | Ràng Buộc & Ghi Chú Kỹ Thuật Bắt Buộc |
| :---: | :---: | :--- | :---: | :--- |
| **D-01** | **D-01** | Mô hình Dịch vụ Backend Cốt lõi (Supabase Managed) | **`APPROVED — ARCHITECTURE ONLY`** | Chấp thuận hướng kiến trúc Supabase PostgreSQL, Auth, Storage, Edge Functions. **Tuyệt đối chưa mua dịch vụ trả phí hay mở project production.** |
| — | **D-01-PRO** | Chính sách Nâng cấp Gói Supabase Pro | **`APPROVED — PROCUREMENT POLICY`** | Chỉ nâng Pro ($25/tháng) khi chứng minh nhu cầu và có phê duyệt riêng. Giai đoạn dev dùng Free tier + dữ liệu giả lập. |
| **D-02** | **D-02** | Phạm vi Dữ liệu Nhập từ GPet cũ | **`APPROVED — DATA SCOPE`** | Chỉ nhập dữ liệu thương mại (khách, sản phẩm, dịch vụ, tồn đầu kỳ, hóa đơn); bệnh án cũ lưu riêng, không chuyển đổi. |
| **D-03** | **D-03** | Chính sách Sao lưu Khắc phục Thảm họa (DR) & PITR | **`APPROVED — BACKUP POLICY`** | Chủ dự án chốt: Giữ bản sao lưu hàng ngày (`pg_dump` mã hóa GPG đẩy lên R2, RPO $\le 24$h, $0); **không mua gói PITR $100/tháng**. |
| **D-04** | **D-04** | Nhà cung cấp Captcha & Chống Tấn Công DDOS | **`APPROVED — SERVICE SELECTION`** | Chủ dự án chọn Phương án A: **Cloudflare Turnstile** ($0, bảo vệ quyền riêng tư, không làm phiền người dùng). |
| **D-05** | **D-05** | Nhà cung cấp SMS OTP Brandname | **`APPROVED — SERVICE SELECTION`** | Chủ dự án chọn **Zalo ZNS (Zalo OA)** cho môi trường sản xuất để tối ưu chi phí (~250-400đ/tin); dev dùng sandbox/test numbers ($0). |
| **D-06** | **D-06** | Chính sách Bảo mật MFA Theo Hành động Nhạy cảm | **`APPROVED — SECURITY POLICY`** | Bắt buộc AAL2 cho Manager/Admin khi thực hiện hành động nhạy cảm (rollback, duyệt import, liên kết SĐT tái cấp). |
| — | **D-06-INVOICE**| Hiển thị Dòng Bán lẻ / Spa & Che giấu Y khoa | **`APPROVED — INVOICE VISIBILITY`** | Hiện dòng bán lẻ/spa an toàn; **cấm tuyệt đối 100% hiển thị thuốc kê đơn, thuốc tiêm, phác đồ điều trị nội bộ cho khách.** |
| **D-07** | **D-07** | Quy tắc Hai Người Phê duyệt Đợt Nhập (Two-Man Rule)| **`APPROVED — GOVERNANCE POLICY`** | Chủ dự án chọn làm theo đề xuất: **Bắt buộc Two-Man Rule ở CSDL** (`approved_by <> uploaded_by`) và Admin AAL2; không dùng cờ override. |
| **D-08** | **D-08** | Cơ chế Phân ca & Quản lý Ca trực | **`APPROVED — SCHEDULING DESIGN`** | Ca trực linh hoạt do Quản lý thiết lập theo lịch thực tế; không hardcode ca cố định 08-14/14-21/21-08. |
| — | **D-08-NIGHT** | Vận hành Trực Đêm tại Bệnh viện | **`CONFIRMED — OPERATIONS`** | **Có người trực tại viện qua đêm**; chưa có khung giờ cố định; tuyệt đối chưa tuyên bố dịch vụ 24/24 trên website. |
| **D-09** | **D-09** | Chính sách Xử lý Số dư Điểm Tích lũy Cũ | **`APPROVED — DATA POLICY`** | Lưu bền vững trong `app.historical_loyalty_points`; khóa không cho tự quy đổi voucher; chờ chính sách mới. |
| **D-10** | **D-10** | Thời hạn Tự động Xóa Video/Ảnh Nội trú | **`APPROVED — RETENTION POLICY`** | **Xóa sau 60 ngày kể từ thời điểm tải lên (`uploaded_at`)**, không neo theo ngày xuất viện. |
| **D-11** | **D-11** | Rà soát Tuân thủ Pháp lý PDPD (Nghị định 13/2023) | **`APPROVED — LEGAL COMPLIANCE`** | Chủ dự án chốt: **Giao nhân sự nội bộ rà soát quy trình**, lập hồ sơ đánh giá tác động NĐ 13 và ký DPA; không thuê luật sư ngoài. |
| **D-12** | **D-12** | Hiển thị Thông tin Y khoa trên Portal Khách hàng | **`APPROVED — CUSTOMER CLINICAL VISIBILITY`** | Chỉ cho xem chẩn đoán/bản tin đã Bác sĩ duyệt (`published`); tuyệt đối giấu thuốc và y lệnh. |
| **D-13** | **D-13** | Tối thiểu hóa Thu thập Định danh Khách hàng | **`APPROVED — PRIVACY DESIGN`** | Không thu thập số CCCD thô trên portal; chỉ đối soát tại quầy khi cần. |
| **D-14** | **D-14** | Kiến trúc Cô lập Máy chủ Worker (1 VPS Container) | **`APPROVED — DESIGN`** | 1 VPS ($5/tháng) cách ly Container non-root (`user: 1000:1000`), deny outbound network, quyền DB tối thiểu. Chưa thuê VPS. |
| **D-15** | **D-15** | Chính sách Xử lý Mặt hàng Thiếu Hạn Sử Dụng | **`APPROVED — INVENTORY POLICY`** | Không tự sinh HSD; gán `unknown` và khóa cách ly (`quarantined`), cấm xuất bán/kê đơn cho đến khi thủ kho xác minh. |
| **D-16** | **D-16** | Nơi Chạy API Backend & Quản lý Bí mật | **`APPROVED — ARCHITECTURE`** | Supabase Edge Functions & Vault ($0 phụ phí, Singapore region); không chạy VPS API riêng. |
| **D-17** | **D-17** | Nền tảng Lưu trữ Website Công Khai (Hosting) | **`APPROVED FOR EVALUATION ONLY`** | Ưu tiên thử nghiệm Cloudflare Pages; chưa chốt cho Production; chưa duyệt dịch vụ trả phí. |
| **D-18** | **D-18** | Xác nhận Đơn vị Hành chính Địa chỉ Cơ sở | **`CONFIRMED — ADDRESS & SEO`** | Chủ dự án xác nhận chính thức: **`101 Khuất Duy Tiến, Phường Nhân Chính, Quận Thanh Xuân, Hà Nội`**; đồng bộ toàn bộ tài liệu và SEO. |
| **D-19** | **D-19** | Cơ chế Tạo Hồ sơ Khách Hàng (Lazy Creation) | **`APPROVED — DESIGN`** | Áp dụng triệt để 10 quy tắc Lazy Profile Creation; không tạo khách rác khi đăng ký Auth. |
| **D-20** | **D-20** | Chính sách Thiết bị Ghi hình & Media (BYOD) | **`APPROVED — DEVICE POLICY`** | Cho phép điện thoại cá nhân với điều kiện: upload qua Web/PWA, khử EXIF/GPS, không lưu bản cá nhân. |
| — | **D-LINK** | Thẩm quyền Phê duyệt Liên kết Tài khoản Khách hàng| **`APPROVED — SECURITY POLICY`** | Tiếp tân chỉ tiếp nhận/đối soát tại quầy; thẩm quyền duyệt `rpc_resolve_recycled_phone` thuộc Quản lý (AAL2). |

---

## II. CHI TIẾT 20 QUYẾT ĐỊNH CỐT LÕI (FULL REGISTER)

### D-01: Mô hình Dịch vụ Backend Cốt lõi (Backend Stack)
- **Trạng thái:** **`APPROVED — ARCHITECTURE ONLY`**
- **Phương án lựa chọn:** Supabase Managed (PostgreSQL + Auth + Storage).
- **Ràng buộc:** Giữ schema `app` riêng tư, truy cập qua wrapper API an toàn trong schema `public`. Chưa mua Supabase Pro ($25/tháng) hay bất kỳ add-on nào. Chưa mở project Production.

### D-01-PRO: Chính sách Mua gói Supabase Pro
- **Trạng thái:** **`APPROVED — PROCUREMENT POLICY`**
- **Phương án lựa chọn:** Chỉ nâng cấp Supabase Pro khi có nhu cầu được chứng minh (khi chuẩn bị go-live thật sự) và được Chủ dự án duyệt riêng bằng văn bản.
- **Ràng buộc:** Môi trường thử nghiệm / Dev dùng Free tier ($0) kết hợp dữ liệu giả lập (mock data). Nhận diện rõ rủi ro Free tier tự động pause sau 7 ngày không hoạt động.

### D-02: Phạm vi Dữ liệu Nhập từ GPet Cũ
- **Trạng thái:** **`APPROVED — DATA SCOPE`**
- **Phương án lựa chọn:** Chỉ nhập dữ liệu thương mại (Khách hàng, Thú cưng, Sản phẩm, Dịch vụ, Tồn kho đầu kỳ, Hóa đơn bán lẻ/spa lịch sử).
- **Ràng buộc:** Tuyệt đối không chuyển đổi bệnh án cũ vào các bảng lâm sàng mới. Dữ liệu bệnh án cũ được đóng gói lưu trữ lạnh riêng biệt. Không xóa file nguồn.

### D-03: Chính sách Sao lưu Khắc phục Thảm họa (DR) & PITR
- **Trạng thái:** **`APPROVED — BACKUP POLICY`**
- **Phương án lựa chọn:** Duy trì giải pháp sao lưu hàng ngày (`pg_dump` mã hóa GPG 4096-bit đẩy lên Cloudflare R2, RPO $\le 24$ giờ, $0 phụ phí).
- **Ràng buộc:** **Quyết định KHÔNG mua gói Supabase PITR trả phí ($100/tháng)** nhằm tối ưu chi phí vận hành theo đúng chỉ đạo của Chủ dự án.

### D-04: Nhà cung cấp Captcha & Chống DDOS
- **Trạng thái:** **`APPROVED — SERVICE SELECTION`**
- **Phương án lựa chọn:** **Chọn Phương án A — Cloudflare Turnstile** ($0 phụ phí, bảo vệ quyền riêng tư người dùng, không làm phiền khách hàng khi đặt lịch).
- **Ràng buộc:** Tích hợp client widget tại form đặt lịch công khai và API verify tại Supabase Edge Functions.

### D-05: Nhà cung cấp SMS OTP Brandname
- **Trạng thái:** **`APPROVED — SERVICE SELECTION`**
- **Phương án lựa chọn:** **Ưu tiên gửi mã xác thực qua Zalo ZNS (Zalo OA)** khi hệ thống bước vào vận hành sản xuất để tối ưu chi phí (~250-400đ/tin).
- **Ràng buộc:** Giai đoạn dev/thử nghiệm tiếp tục dùng số sandbox / test numbers ($0).

### D-06: Chính sách Bảo mật MFA Theo Hành động Nhạy cảm
- **Trạng thái:** **`APPROVED — SECURITY POLICY`**
- **Phương án lựa chọn:** Bắt buộc MFA (TOTP AAL2) cho Quản lý / Quản trị viên khi thực hiện các hành vi nhạy cảm: duyệt import dữ liệu, rollback dữ liệu, giải quyết số điện thoại tái cấp.
- **Ràng buộc:** Không cấp quyền xem/sửa bệnh án chỉ bằng mật khẩu đơn cấp AAL1.

### D-06-INVOICE: Hiển thị Dòng Bán lẻ / Spa & Che giấu Y khoa
- **Trạng thái:** **`APPROVED — INVOICE VISIBILITY`**
- **Phương án lựa chọn:** Hiển thị cho khách hàng các dòng bán lẻ và spa đã được hệ thống phân loại an toàn (`is_clinical_hidden = FALSE`).
- **Ràng buộc:** Cấm 100% hiển thị thuốc kê đơn, thuốc tiêm, dịch vụ phẫu thuật nội trú, y lệnh điều trị nội bộ. Trigger tự động tra cứu catalog trước, fail-safe `COALESCE(..., TRUE)`.

### D-07: Quy tắc Hai Người Phê duyệt Đợt Nhập (Two-Man Rule)
- **Trạng thái:** **`APPROVED — GOVERNANCE POLICY`**
- **Phương án lựa chọn:** **Làm theo đề xuất (Phương án A) — Bắt buộc Two-Man Rule ở CSDL** (`approved_by <> uploaded_by`) và Admin AAL2 qua `app.rpc_import_approve_job`.
- **Ràng buộc:** Không dùng cờ Override khẩn cấp; người tải file lên tuyệt đối không thể tự duyệt đợt nhập của chính mình.

### D-08: Cơ chế Phân ca & Quản lý Ca trực
- **Trạng thái:** **`APPROVED — SCHEDULING DESIGN`**
- **Phương án lựa chọn:** Ca trực linh hoạt do Quản lý thiết lập theo lịch phân công thực tế của bệnh viện.
- **Ràng buộc:** Không hardcode ca cố định 08-14, 14-21, 21-08 làm lịch mặc định đã chốt.

### D-08-NIGHT: Vận hành Trực Đêm tại Bệnh viện
- **Trạng thái:** **`CONFIRMED — OPERATIONS`**
- **Phương án lựa chọn:** Bệnh viện xác nhận có người trực tại cơ sở qua đêm để theo dõi thú cưng nội trú.
- **Ràng buộc:** Chưa có khung giờ đêm cụ thể; tuyệt đối chưa tự ý biến thành tuyên bố "Dịch vụ cấp cứu 24/24" trên website công khai.

### D-09: Chính sách Xử lý Số dư Điểm Tích lũy Cũ
- **Trạng thái:** **`APPROVED — DATA POLICY`**
- **Phương án lựa chọn:** Lưu trữ bền vững số dư điểm GPet lịch sử trong bảng `app.historical_loyalty_points`, khóa cứng `is_locked = TRUE`.
- **Ràng buộc:** Tuyệt đối không tự động quy đổi điểm cũ thành voucher hay tiền mặt; chờ Chủ dự án ban hành chính sách khách hàng thân thiết mới.

### D-10: Thời hạn Tự động Xóa Video/Ảnh Nội trú
- **Trạng thái:** **`APPROVED — RETENTION POLICY`**
- **Phương án lựa chọn:** Tự động xóa media lưu viện sau 60 ngày kể từ thời điểm tải lên (`uploaded_at`).
- **Ràng buộc:** Thay đổi mốc tính từ ngày xuất viện sang ngày tải lên để đảm bảo quy trình Cron Worker chạy đồng bộ và dự toán chi phí lưu trữ chính xác.

### D-11: Khung Pháp lý Bảo vệ Dữ liệu (PDPD - Nghị định 13/2023)
- **Trạng thái:** **`APPROVED — LEGAL COMPLIANCE`**
- **Phương án lựa chọn:** **Giao nhân sự nội bộ rà soát:** Chuẩn bị hồ sơ đánh giá tác động chuyển dữ liệu ra nước ngoài theo Nghị định 13/2023/NĐ-CP và ký thỏa thuận DPA với Supabase; bảo lưu bệnh án thú y.
- **Ràng buộc:** Không thuê đơn vị tư vấn luật bên ngoài để tiết kiệm chi phí; chỉ tiếp nhận dữ liệu thật sau khi nhân sự nội bộ hoàn tất rà soát.

### D-12: Hiển thị Thông tin Y khoa trên Portal Khách hàng
- **Trạng thái:** **`APPROVED — CUSTOMER CLINICAL VISIBILITY`**
- **Phương án lựa chọn:** Chỉ hiển thị các thông tin chẩn đoán và bản tin đã được Bác sĩ phê duyệt phát hành (`published`).
- **Ràng buộc:** Tuyệt đối không hiển thị tên thuốc nội bộ, liều lượng, giờ tiêm, lịch tiêm, phác đồ điều trị hay y lệnh nội bộ.

### D-13: Tối Thiểu Hóa Thu Thập Định Danh Khách Hàng
- **Trạng thái:** **`APPROVED — PRIVACY DESIGN`**
- **Phương án lựa chọn:** Tuyệt đối không thu thập số CCCD thô trên portal trực tuyến; chỉ dùng SĐT + Họ tên + Tên thú cưng.
- **Ràng buộc:** Xác minh CCCD chỉ thực hiện trực tiếp tại quầy tiếp tân khi khách hàng yêu cầu liên kết hồ sơ lịch sử phức tạp.

### D-14: Kiến Trúc Cô Lập Máy Chủ Worker
- **Trạng thái:** **`APPROVED — DESIGN`**
- **Phương án lựa chọn:** 1 VPS ($5.00/tháng - Hetzner CX22 / DigitalOcean) cách ly bằng Docker Container phi-root (`user: 1000:1000`).
- **Ràng buộc:** Parser Container không có Default Gateway ra Internet, tường lửa chỉ Allowlist Supabase; DR Backup Worker chạy Systemd tách biệt. Chưa thuê VPS.

### D-15: Chính sách Xử Lý Hạn Sử Dụng Thiếu
- **Trạng thái:** **`APPROVED — INVENTORY POLICY`**
- **Phương án lựa chọn:** Tuyệt đối không tự sinh HSD giả tạo; gán trạng thái `unknown` và đưa vào diện cách ly (`quarantined`), cấm xuất bán cho đến khi kiểm kho thực tế.

### D-16: Nơi Chạy Máy Chủ API & Quản Lý Bí Mật
- **Trạng thái:** **`APPROVED — ARCHITECTURE`**
- **Phương án lựa chọn:** Supabase Edge Functions (Deno, Singapore, $0 phụ phí) kết hợp Supabase Vault để quản trị secret keys.
- **Ràng buộc:** Không dựng Node.js API Service riêng biệt trên VPS.

### D-17: Nhà Cung Cấp Lưu Trữ Website Công Khai (Hosting)
- **Trạng thái:** **`APPROVED FOR EVALUATION ONLY`**
- **Phương án lựa chọn:** Ưu tiên đánh giá Cloudflare Pages (tương thích React Router 7/Vite SPA, CDN toàn cầu, Turnstile tích hợp, $0 phụ phí).
- **Ràng buộc:** Chưa phê duyệt chính thức cho Production; chưa mua tài khoản Vercel Pro ($20/tháng).

### D-18: Xác Nhận Đơn Vị Hành Chính Địa Chỉ Cơ Sở
- **Trạng thái:** **`CONFIRMED — ADDRESS & SEO`**
- **Phương án lựa chọn:** Chủ dự án xác nhận chính thức địa chỉ bệnh viện: **`101 Khuất Duy Tiến, Phường Nhân Chính, Quận Thanh Xuân, Hà Nội`**.
- **Ràng buộc:** Đồng bộ 100% với tài liệu SEO (`docs/seo-strategy.md`), chân trang website và khai báo thẻ Schema.org `LocalBusiness`.

### D-19: Cơ Chế Tạo Hồ Sơ Khách Khi Đăng Ký (Lazy Creation)
- **Trạng thái:** **`APPROVED — DESIGN`**
- **Phương án lựa chọn:** Áp dụng triệt để 10 quy tắc Lazy Customer Profile Creation: Đăng ký Auth bằng OAuth/Email chỉ tạo bản ghi `app.users`, không tạo bản ghi `app.customers` rác; chỉ tạo hồ sơ khi thực sự phát sinh giao dịch đặt lịch/khám chữa tại quầy.

### D-20: Chính Sách Thiết Bị Ghi Hình & Media (BYOD)
- **Trạng thái:** **`APPROVED — DEVICE POLICY`**
- **Phương án lựa chọn:** Cho phép nhân viên dùng điện thoại cá nhân (BYOD) tải ảnh/video qua ứng dụng Web PWA chuyên dụng của bệnh viện.
- **Ràng buộc:** Tuân thủ triệt để Kiến trúc Bảo mật BYOD 5 Tầng (Mục VII.5.C): (1) In-memory capture qua HTML5 PWA, cấm ghi vào Camera Roll cá nhân; (2) Khử EXIF/GPS 2 tầng (Canvas client + Sharp/FFmpeg worker); (3) Ràng buộc phiên thiết bị qua bảng `app.staff_device_sessions` và RPC thu hồi `app.rpc_revoke_staff_device`; (4) Hook PWA Remote Wipe zeroize sạch dữ liệu/cache cục bộ khi bị thu hồi phiên; (5) Giới hạn ảnh $\le 15$MB, video $\le 50$MB/60s, Signed URL 15 phút, auto-purge 60 ngày. Không bắt buộc mua tablet chuyên dụng.

### D-LINK: Thẩm quyền Phê duyệt Liên kết Tài khoản Khách hàng
- **Trạng thái:** **`APPROVED — SECURITY POLICY`**
- **Phương án lựa chọn:** Tiếp tân chỉ tiếp nhận và lập phiếu yêu cầu đối soát tại quầy (`app.user_link_requests`); thẩm quyền phê duyệt hoặc xử lý SĐT tái cấp thuộc về Quản lý / Admin có MFA AAL2 (`app.rpc_resolve_recycled_phone`).
